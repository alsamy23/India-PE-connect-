import express from "express";
import "dotenv/config";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

app.use(express.json({ limit: "10mb" }));

// ─── Anthropic Claude API Helper ───────────────────────────────────────────
const ANTHROPIC_API_URL = "https://api.anthropic.com/v1/messages";
const ANTHROPIC_MODEL = "claude-sonnet-4-20250514";

const callClaude = async (systemPrompt: string, userPrompt: string): Promise<string> => {
  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    throw new Error("ANTHROPIC_API_KEY is not set. Please add it in your Vercel Environment Variables.");
  }

  const response = await fetch(ANTHROPIC_API_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": apiKey,
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify({
      model: ANTHROPIC_MODEL,
      max_tokens: 4096,
      system: systemPrompt,
      messages: [{ role: "user", content: userPrompt }],
    }),
  });

  if (!response.ok) {
    const errText = await response.text();
    throw new Error(`Anthropic API error ${response.status}: ${errText}`);
  }

  const data: any = await response.json();
  return data?.content?.[0]?.text || "";
};

// Convert Gemini-style request body to Claude call
const handleGenerate = async (req: express.Request, res: express.Response) => {
  const { contents, config } = req.body;

  // Extract prompt text from Gemini-style contents
  let userPrompt = "";
  if (typeof contents === "string") {
    userPrompt = contents;
  } else if (contents?.parts) {
    userPrompt = contents.parts.map((p: any) => p.text || "").join("\n");
  } else if (Array.isArray(contents)) {
    userPrompt = contents
      .map((c: any) =>
        typeof c === "string" ? c : c.parts ? c.parts.map((p: any) => p.text || "").join("\n") : ""
      )
      .join("\n");
  }

  const systemPrompt = config?.systemInstruction || "You are a helpful Physical Education assistant for Indian teachers.";
  const expectJson = config?.responseMimeType === "application/json";

  const finalSystem = expectJson
    ? systemPrompt +
      "\n\nCRITICAL: Your ENTIRE response must be ONLY a valid JSON object. No explanation, no markdown, no code fences (```), no extra text before or after. Start with { and end with }."
    : systemPrompt;

  try {
    const text = await callClaude(finalSystem, userPrompt);
    return res.json({ text, provider: "claude", model: ANTHROPIC_MODEL });
  } catch (err: any) {
    console.error("Claude API error:", err.message);
    return res.status(500).json({
      error: err.message || "AI generation failed.",
      message: err.message,
    });
  }
};

// ─── API Routes ────────────────────────────────────────────────────────────
const apiRouter = express.Router();

apiRouter.get("/health", (_req, res) => {
  const hasKey = !!process.env.ANTHROPIC_API_KEY;
  res.json({
    status: hasKey ? "ok" : "missing_key",
    provider: "claude",
    model: ANTHROPIC_MODEL,
    hasKey,
  });
});

apiRouter.get("/ai/test", async (_req, res) => {
  try {
    const text = await callClaude("You are a helpful assistant.", "Say exactly: Claude Connection Successful");
    return res.json({ message: text, provider: "claude" });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

apiRouter.post("/ai/generate", handleGenerate);

app.use("/api", apiRouter);

// ─── Start Server ──────────────────────────────────────────────────────────
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    console.log("Starting in development mode with Vite middleware...");
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true, hmr: { port: 24679 } },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    console.log("Starting in production mode...");
    const distPath = path.resolve(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get(/.*/, (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.use("/api", (_req, res) => {
    res.status(404).json({ error: "API endpoint not found" });
  });

  if (process.env.NODE_ENV !== "production" || !process.env.VERCEL) {
    app.listen(PORT, "0.0.0.0", () => {
      console.log(`Server running on http://localhost:${PORT}`);
      console.log(`AI Provider: Anthropic Claude (${ANTHROPIC_MODEL})`);
    });
  }
}

startServer().catch((err) => {
  console.error("Failed to start server:", err);
});

export default app;
