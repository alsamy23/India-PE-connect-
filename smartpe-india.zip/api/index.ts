import express from "express";
import { GoogleGenAI } from "@google/genai";
import Groq from "groq-sdk";
import "dotenv/config";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

app.use(express.json());

// Secure AI Initialization (Server-side only)
const getGeminiKeys = () => {
  const keys: string[] = [];
  const standardNames = ["GEMINI_API_KEY", "API_KEY", "VITE_GEMINI_API_KEY"];
  standardNames.forEach(name => {
    const val = process.env[name];
    if (val && val.trim() !== "" && val !== "undefined" && val !== "null") {
      keys.push(val.trim().replace(/^["']|["']$/g, ''));
    }
  });

  for (let i = 1; i <= 20; i++) {
    const key = process.env[`GEMINI_KEY_${i}`];
    if (key && key.trim() !== "" && key !== "undefined" && key !== "null") {
      keys.push(key.trim().replace(/^["']|["']$/g, ''));
    }
  }
  return [...new Set(keys)].filter(k => k.length > 10);
};

const getGroqKey = () => {
  const key = process.env.GROQ_API_KEY;
  if (key && key.trim() !== "" && key !== "undefined" && key !== "null") {
    return key.trim().replace(/^["']|["']$/g, '');
  }
  return null;
};

const getAI = () => {
  const geminiKeys = getGeminiKeys();
  const groqKey = getGroqKey();
  
  return { 
    hasGemini: geminiKeys.length > 0,
    hasGroq: !!groqKey,
    geminiCount: geminiKeys.length
  };
};

// API Routes
const apiRouter = express.Router();

apiRouter.get("/health", (req, res) => {
  try {
    const status = getAI();
    res.json({ 
      status: (status.hasGemini || status.hasGroq) ? "ok" : "missing",
      ...status
    });
  } catch (err: any) {
    res.status(500).json({ status: "error", message: "Health check failed" });
  }
});

apiRouter.get("/ai/test", async (req, res) => {
  try {
    const geminiKeys = getGeminiKeys();
    if (geminiKeys.length > 0) {
      const ai = new GoogleGenAI({ apiKey: geminiKeys[0] });
      const response = await ai.models.generateContent({
        model: "gemini-flash-latest",
        contents: "Say 'Gemini Connection Successful'"
      });
      return res.json({ message: response.text, provider: "gemini" });
    }
    
    const groqKey = getGroqKey();
    if (groqKey) {
      const groq = new Groq({ apiKey: groqKey });
      const completion = await groq.chat.completions.create({
        messages: [{ role: "user", content: "Say 'Groq Connection Successful'" }],
        model: "llama3-70b-8192",
      });
      return res.json({ message: completion.choices[0]?.message?.content, provider: "groq" });
    }

    res.status(401).json({ error: "No AI API keys found" });
  } catch (error: any) {
    res.status(500).json({ error: error.message || "Test failed" });
  }
});

apiRouter.post("/ai/generate", async (req, res) => {
  const { model, contents, config } = req.body;
  const geminiKeys = getGeminiKeys();
  const groqKey = getGroqKey();
  
  if (geminiKeys.length === 0 && !groqKey) {
    return res.status(500).json({ error: "No AI API keys configured (Gemini or Groq)." });
  }

  let lastError: any = null;

  // 1. Try Gemini first (with rotation)
  if (geminiKeys.length > 0) {
    const shuffledKeys = [...geminiKeys].sort(() => Math.random() - 0.5);
    for (const key of shuffledKeys) {
      try {
        const ai = new GoogleGenAI({ apiKey: key });
        const response = await ai.models.generateContent({
          model: model || "gemini-flash-latest",
          contents,
          config
        });

        return res.json({
          text: response.text,
          provider: "gemini",
          candidates: response.candidates
        });
      } catch (error: any) {
        lastError = error;
        const errorMsg = (error.message || "").toLowerCase();
        const isQuotaError = errorMsg.includes("429") || error.status === 429 || errorMsg.includes("resource_exhausted") || errorMsg.includes("quota");
        const isInvalidKeyError = errorMsg.includes("400") || error.status === 400 || 
                                 errorMsg.includes("api_key_invalid") || errorMsg.includes("api key not valid") || 
                                 errorMsg.includes("expired") || errorMsg.includes("invalid_argument");

        if (isQuotaError || isInvalidKeyError) {
          console.warn(`Gemini key hit ${isQuotaError ? 'quota' : 'invalid/expired'} error. Trying next...`);
          continue;
        }
        break; 
      }
    }
  }

  // 2. Fallback to Groq if Gemini failed or wasn't available
  if (groqKey) {
    try {
      console.log("Falling back to Groq...");
      const groq = new Groq({ apiKey: groqKey });
      
      // Convert Gemini format to OpenAI/Groq format
      let prompt = "";
      if (typeof contents === 'string') {
        prompt = contents;
      } else if (contents.parts) {
        prompt = contents.parts.map((p: any) => p.text).join("\n");
      } else if (Array.isArray(contents)) {
        prompt = contents.map((c: any) => typeof c === 'string' ? c : (c.parts ? c.parts.map((p: any) => p.text).join("\n") : "")).join("\n");
      }

      const systemPrompt = config?.systemInstruction || "You are a helpful assistant.";
      
      const completion = await groq.chat.completions.create({
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: prompt }
        ],
        model: "llama3-70b-8192",
        temperature: config?.temperature || 0.7,
        response_format: config?.responseMimeType === "application/json" ? { type: "json_object" } : undefined
      });

      return res.json({
        text: completion.choices[0]?.message?.content,
        provider: "groq"
      });
    } catch (groqError: any) {
      console.error("Groq fallback failed:", groqError);
      lastError = groqError;
    }
  }

  let errorMessage = "AI generation failed after trying all available providers.";
  if (lastError?.message?.toLowerCase().includes("expired")) {
    errorMessage = "Your Gemini API key has expired. Please update it in the Environment Variables or add a Groq key as a fallback.";
  } else if (lastError?.message?.toLowerCase().includes("quota") || lastError?.message?.toLowerCase().includes("429")) {
    errorMessage = "Gemini quota exceeded and no Groq fallback is configured. Please add a Groq API key for uninterrupted service.";
  }

  res.status(500).json({ 
    error: errorMessage,
    originalError: lastError?.message,
    details: lastError?.stack
  });
});

// Mount API routes
app.use("/api", apiRouter);

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    console.log("Starting in development mode with Vite middleware...");
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { 
        middlewareMode: true,
        hmr: { port: 24679 } // Use a different port for HMR to avoid conflicts
      },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    console.log("Starting in production mode...");
    const distPath = path.resolve(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get(/.*/, (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  // Error handler for API
  app.use("/api", (req, res) => {
    res.status(404).json({ error: "API endpoint not found" });
  });

  if (process.env.NODE_ENV !== "production" || !process.env.VERCEL) {
    app.listen(PORT, "0.0.0.0", () => {
      console.log(`Server running on http://localhost:${PORT}`);
    });
  }
}

startServer().catch(err => {
  console.error("Failed to start server:", err);
});

export default app;
